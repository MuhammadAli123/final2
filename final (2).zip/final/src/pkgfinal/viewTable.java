package pkgfinal;


import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;

//import java.awt.Image;
import java.io.FileOutputStream;
import static java.lang.String.valueOf;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
//import javax.swing.text.Document;
import net.proteanit.sql.DbUtils;
import java.awt.event.*;
import java.awt.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import static javax.swing.UIManager.getString;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ali
 */
public class viewTable extends javax.swing.JFrame {

    Connection conn = null;
        ResultSet rs = null;
        PreparedStatement pst = null;
    
    public viewTable() {
        initComponents();
        
       conn = conn2.DB();
       combobox();
       icon();
       currentDate();
    }
 //  methods m = new methods();
   createTable ct =new   createTable();
   
 public void Update_table(){        /*update_table_sale*/

        try{
    String sql ="select * from  '"+jComboBox1.getSelectedItem()+"' order by ID";
    pst = conn.prepareStatement(sql);
    rs = pst.executeQuery();
    table.setModel(DbUtils.resultSetToTableModel(rs));
        
        }
    catch(Exception e){

     JOptionPane.showMessageDialog(null, e);
    }
        finally{
        try{
        rs.close();
        pst.close();
       }
        catch(Exception e){
        }
       }
        }
   
    private void combobox(){
    
            try{
            
           //     String sql3 ="SELECT * FROM SalPur.sqlite_master WHERE type='table'";
                String sql4 ="SELECT name FROM sqlite_master WHERE type='table'";
           //     String sql="select * from sys.tables";
           //     String sql5="select sys.table from sqlite_master";
                 pst = conn.prepareStatement(sql4);
                 rs = pst.executeQuery(); 
     
               while(rs.next()){
                   
                   jComboBox1.addItem(rs.getString(1)); 
                   PurCom.addItem(rs.getString(1));
                   SalCom.addItem(rs.getString(1));
                }  
              }
                catch(Exception e){
                 JOptionPane.showMessageDialog(null, "combox");
                 }
                  finally{
     
                   try{
                    rs.close();
                    pst.close();
                      }
                  catch(Exception e){
                    }
                   }
    }
    
     public void close(){
     
      WindowEvent ClosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
      Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(ClosingEvent);
     }
  
     public void icon(){
     
       JFrame frame = new JFrame();
       setTitle("Bussines Manager 1.0");
       setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("CIcon.jpg")));
     }
    
     public void currentDate(){
     
       Thread clock  = new Thread(){
       
         public void run(){
         
           for(;;){
              
               try{
                 Calendar cal = new GregorianCalendar();
                 int day = cal.get(Calendar.DAY_OF_MONTH);
                 int month = cal.get(Calendar.MONTH);
                 int year = cal.get(Calendar.YEAR);
                 Date.setText(" Date: "+day+"/"+(month+1)+"/"+year+" ");
                 
                 int sec = cal.get(Calendar.SECOND);
                 int min = cal.get(Calendar.MINUTE);
                 int hour = cal.get(Calendar.HOUR);
               //  int amPm = 9;
             //    int amPm = cal.get(Calendar.AM_PM);
                 time_txt.setText("Time: "+hour+":"+min+":"+sec+" "); //
                 sleep(1000);
               }
              catch(InterruptedException ex){
                Logger.getLogger(viewTable.class.getName()).log(Level.SEVERE, null, ex);
              } 
           }  
         }
      };
       clock.start();
     }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox();
        jPanel7 = new javax.swing.JPanel();
        jButton12 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        T_pur = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        T_sale = new javax.swing.JTextField();
        T_Quantity = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        search_tf = new javax.swing.JTextField();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jButton13 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        date_tf = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        BRname_tf = new javax.swing.JTextField();
        purchase_tf = new javax.swing.JTextField();
        id_tf = new javax.swing.JTextField();
        MAname_tf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        Add_Sub = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        sale_tf = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        Sale_Add_Sub = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        total = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        Clear = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        sno = new javax.swing.JTextField();
        date = new com.toedter.calendar.JDateChooser();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        PurCom = new javax.swing.JComboBox();
        brand = new javax.swing.JTextField();
        purchase = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        snoS = new javax.swing.JTextField();
        dateS = new com.toedter.calendar.JDateChooser();
        brandS = new javax.swing.JTextField();
        SalQ = new javax.swing.JTextField();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        SalCom = new javax.swing.JComboBox();
        jLabel25 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        recordT = new javax.swing.JTable();
        jButton19 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jToolBar1 = new javax.swing.JToolBar();
        Date = new javax.swing.JLabel();
        time_txt = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        Date_txt = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 750));

        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Table Name" }));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBox1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jComboBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox1MouseClicked(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(204, 204, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Total Quantity", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 14), new java.awt.Color(255, 51, 102))); // NOI18N

        jButton12.setText("Total Quantities");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jLabel11.setText("Total Sale");

        jLabel10.setText("Total Purchase");

        jLabel12.setText("Total Quantity");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(jButton12))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(T_pur, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(T_sale, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(T_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(T_pur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_sale, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton12)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/PRI.PNG"))); // NOI18N
        jButton10.setText("Print");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/save.png"))); // NOI18N
        jButton11.setText("save Report");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(204, 204, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 102, 255))); // NOI18N

        search_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_tfKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_tf, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "title ", "null", "Title 7"
            }
        ));
        table.setToolTipText("Table");
        table.setMinimumSize(new java.awt.Dimension(60, 120));
        table.setRowHeight(30);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        table.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/de.PNG"))); // NOI18N
        jButton13.setText("Delete");
        jButton13.setToolTipText("delete item");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(102, 255, 0));
        jLabel20.setText("jLabel20");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 797, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 417, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton13)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("View Table", jPanel9);

        jPanel10.setPreferredSize(new java.awt.Dimension(845, 450));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase Data", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 51, 255))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Id");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Manufacture Name");

        purchase_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchase_tfActionPerformed(evt);
            }
        });

        MAname_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MAname_tfActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Purchase Quantity");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Date");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Brand Name");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(purchase_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BRname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(MAname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(date_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(id_tf)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(date_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(BRname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(MAname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(purchase_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 51, 255))); // NOI18N

        jLabel8.setText("Purchase / Purchase Return");

        jButton3.setText("Add");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Sub");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addGap(44, 44, 44)
                .addComponent(Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addGap(23, 23, 23))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale Detail", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 51, 255))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Sale Quantity");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(27, 27, 27)
                .addComponent(sale_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(sale_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale Return", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 51, 255))); // NOI18N

        jLabel9.setText("Sale Return");

        Sale_Add_Sub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Sale_Add_SubActionPerformed(evt);
            }
        });

        jButton5.setText("Add");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Sub");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(Sale_Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addGap(18, 18, 18)
                .addComponent(jButton6)
                .addGap(22, 22, 22))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addComponent(Sale_Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton5)
                    .addComponent(jButton6)))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Total Detail", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 51, 255))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Total Quantity");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(27, 27, 27)
                .addComponent(total, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(total, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel6.setBackground(new java.awt.Color(204, 204, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buttons", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/save.png"))); // NOI18N
        jButton7.setText("Save");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/de.PNG"))); // NOI18N
        jButton8.setText("Delete");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        Clear.setText("Clear");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/up.PNG"))); // NOI18N
        jButton9.setText("Update");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton8)
                        .addGap(6, 6, 6))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jButton9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton8)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(4, 4, 4)))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
        );

        jTabbedPane1.addTab("Information Input", jPanel10);

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase Input", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12), new java.awt.Color(204, 204, 255))); // NOI18N

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("Serial no");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setText("Date");

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel15.setText("Manufacture Name");

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setText("Brand Name");

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel17.setText("purchase Quantity");

        PurCom.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Table" }));
        PurCom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PurComActionPerformed(evt);
            }
        });

        brand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brandActionPerformed(evt);
            }
        });

        purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchaseActionPerformed(evt);
            }
        });

        jButton2.setText("Save");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton14.setText("Update");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setText("Clear");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jButton15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 262, Short.MAX_VALUE)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton14)
                        .addGap(152, 152, 152))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16)
                            .addComponent(jLabel14)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jLabel13))
                            .addComponent(jLabel17))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PurCom, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(date, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                            .addComponent(brand)
                            .addComponent(purchase)
                            .addComponent(sno))
                        .addContainerGap(356, Short.MAX_VALUE))))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13)
                    .addComponent(sno, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(PurCom, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(brand, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton14)
                    .addComponent(jButton15))
                .addGap(33, 33, 33))
        );

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(102, 255, 0));
        jLabel19.setText("jLabel19");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(85, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Purchase", jPanel11);

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Daily Sale ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12), new java.awt.Color(204, 204, 255))); // NOI18N

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel18.setText("Serial no");

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel21.setText("Date");

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel22.setText("Manufacture Name");

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel23.setText("Brand Name");

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel24.setText("Sale Quantity");

        jButton16.setText("Clear");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setText("Save");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setText("Update");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        SalCom.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item" }));
        SalCom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalComActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22)
                            .addComponent(jLabel23)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(snoS)
                                    .addComponent(dateS, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                                    .addComponent(brandS)
                                    .addComponent(SalQ)))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(SalCom, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jButton16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 246, Short.MAX_VALUE)
                        .addComponent(jButton17)
                        .addGap(28, 28, 28)
                        .addComponent(jButton18)
                        .addGap(131, 131, 131))))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(snoS, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addGap(16, 16, 16))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(dateS, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addGap(30, 30, 30))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(SalCom)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(brandS, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(SalQ, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton16)
                    .addComponent(jButton17)
                    .addComponent(jButton18))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(102, 255, 0));
        jLabel25.setText("jLabel25");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(118, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Daily Sale", jPanel12);

        recordT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        recordT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recordTMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(recordT);

        jButton19.setText("show");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 797, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton19)
                .addGap(71, 71, 71))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton19)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Stock Reprt", jPanel13);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/res.PNG"))); // NOI18N
        jButton1.setToolTipText("Go Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jToolBar1.setRollover(true);

        Date.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Date.setText("Date");
        jToolBar1.add(Date);

        time_txt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        time_txt.setText("Time");
        jToolBar1.add(time_txt);

        Date_txt.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("New");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        Date_txt.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Close");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        Date_txt.add(jMenuItem2);

        jMenuBar1.add(Date_txt);

        jMenu2.setText("Edit");

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText("Clear");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(82, 82, 82)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 802, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jButton10)
                        .addGap(18, 18, 18)
                        .addComponent(jButton11))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(36, 36, 36))
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton10)
                                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(29, 29, 29)
                                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(63, 63, 63)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(37, Short.MAX_VALUE)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBox1PopupMenuWillBecomeInvisible
      // comboxSelect();
    //    String temp =(String)jComboBox1.getSelectedItem();
     //   table.setModel(ct.tname).jComboBox1.getSelectedItem();
 /*    try{
        int row = table.getSelectedRow();
        String table_click =(table.getModel().getValueAt(row, 0).toString());
        
        String sql ="select * from "+ct.tname+" where Id="+table_click+" ";
        
        String sql1 ="SELECT * FROM sqlite_master WHERE type='table'";
        table.setModel().jComboBox1.getSelectedItem();
       
        pst = conn.prepareStatement(sql1);
       pst.setString(1, temp);
       rs = pst.executeQuery();
       
       if(rs.next()){
       
       String val1 = rs.getString("Id");
       Date val2 = rs.getDate("date");
       String val3 = rs.getString("BrandName");
       String val4 = rs.getString("ManufactureName");
       String val5 = rs.getString("PurchaseQuantity");
       String val6 = rs.getString("SaleQuantity");
       String val7 = rs.getString("TotalQuantity");
       }
       }
       catch(Exception e){
        JOptionPane.showMessageDialog(null,"combox2");
       }   
*/

//        String sql7 ="SELECT name FROM sqlite_master WHERE type='table'";
//         String tempt =(String)jComboBox1.getSelectedItem();
    /*      try{
                String sql7 ="SELECT name FROM sqlite_master WHERE type='table'";
         String tempt =(String)jComboBox1.getSelectedItem();
       pst = conn.prepareStatement(sql7);
       pst.setString(1, tempt);
       rs = pst.executeQuery();
       if(rs.next()){
         
           table.setModel((TableModel) rs);
       }   
          }
        catch(Exception e){
        JOptionPane.showMessageDialog(null,"combox3");
       }  */
    }//GEN-LAST:event_jComboBox1PopupMenuWillBecomeInvisible

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
//    
        
            try{
             //   if(jComboBox1.getSelectedItem()== jComboBox1.getSelectedItem()+"_sale"){}else{}
   String sql =" select * from  '"+jComboBox1.getSelectedItem()+"' ";   /*"_sale"*/
    pst = conn.prepareStatement(sql);
    rs = pst.executeQuery();
    table.setModel(DbUtils.resultSetToTableModel(rs));
    jLabel20.setText("right now you are watching "+jComboBox1.getSelectedItem().toString()+" Record");   
        }
    catch(Exception e){

     JOptionPane.showMessageDialog(null, e);
    }
        finally{
        try{
        rs.close();
        pst.close();
       }
        catch(Exception e){
        }
       }

            
            
       /*     try{
               String sql = "select sum(PurchaseQuantity), sum(SaleQuantity), sum(TotalQuantity) from '"+jComboBox1.getSelectedItem()+"'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            recordT.setModel(DbUtils.resultSetToTableModel(rs));
            
                 if(rs.next()){
                     //     for(int a =1; a<=sql.length(); a++){

                String sum1 = rs.getString("sum(PurchaseQuantity)");
             //    recordT.addItem(sum1);
               
                String sum2= rs.getString("sum(SaleQuantity)");
            //    T_sale.setText(sum2);
                
                String sum3 = rs.getString("sum(TotalQuantity)");
            //    T_Quantity.setText(sum3);
            }
            }
            catch(Exception e){}    */
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        options op = new options();
        op.setVisible(true);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MouseClicked
       
//         try{
//            String row= (String) jComboBox1.getSelectedItem();
//        String Table_click = (table.getModel().toString());
//        String sql = "select * from '"+row+"' where Id= '"+Table_click+"' ";
//        
//        pst = conn.prepareStatement(sql);
//        rs = pst.executeQuery();
//        
//        if(rs.next()){
//        
//            String add1 =rs.getString("Id");
//          //  EmployeeID_text.setText(add1);
//             Date add2 =rs.getDate("date");
//         //   Name_text.setText(add2);
//             String add3 =rs.getString("BrandName");
//          //  Surname_text.setText(add3);
//             String add4 =rs.getString("ManufactureName");
//          //  Age_text.setText(add4);
//             String add5 =rs.getString("PurchaseQuantity");
//             String add6 =rs.getString("SaleQuantity");
//             String add7 =rs.getString("TotalQuantity");
//        }
//        
//        }
//        catch(Exception e){
//        JOptionPane.showMessageDialog(null, e);
//        }
    }//GEN-LAST:event_jComboBox1MouseClicked

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
       
         MessageFormat header = new MessageFormat(" '"+jComboBox1.getSelectedItem()+"' Report");
        MessageFormat footer = new MessageFormat("Page{0,number,integer}");
        
        try{
          table.print(JTable.PrintMode.NORMAL, header, footer);
        }
        catch(java.awt.print.PrinterException e){
            System.err.format("Cannot print %s%n", e.getMessage());
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        
          try{
      
     
            
        Document document = new Document();
        
       PdfWriter.getInstance(document,new FileOutputStream(" "+jComboBox1.getSelectedItem()+".pdf"));
        document.open();
     //   Image image =  Image.getInstance("save.png");
   //     document.add(new Paragraph("image"));
    //    document.add(image);
        document.add(new Paragraph("ECHO TRADERS",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.RED)));
        document.add(new Paragraph(" "+jComboBox1.getSelectedItem()+ "  Report ",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.BLUE)));
        document.add(new Paragraph(new java.util.Date().toString())) ;
        document.add(new Paragraph("--------------------------------------------------------"));
        PdfPTable table = new PdfPTable(7);
        PdfPCell cell= new PdfPCell (new Paragraph("Purcahse_Sale Report"));
        PdfPCell cell1= new PdfPCell (new Paragraph("ID |   Date |  BrandName | ManufacName | PurQt |  SalQT |  TotalQt "));
        
        cell.setColspan(7);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBackgroundColor(BaseColor.GREEN);
        table.addCell(cell);
        
        cell1.setColspan(7);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setBackgroundColor(BaseColor.PINK);
        table.addCell(cell1);
        
        
        String sql = "select * from '"+jComboBox1.getSelectedItem()+"' ";
             pst = conn.prepareStatement(sql);
          rs=pst.executeQuery();
      while(rs.next()){
                       
                        String v1 = rs.getString("ID");
                        String add = rs.getString("Date");          
                        String v2 = rs.getString("BrandName");
                        String v3 = rs.getString("ManufactureName");
                        String v4 = rs.getString("PurchaseQuantity");
                        String v5 =rs.getString("SaleQuantity");
                        String v6 =rs.getString("TotalQuantity");

                  //  table.addCell("ID");
                    table.addCell(v1);
           //        table.addCell(v/*.date_tf.getDateFormatString()*/);
                    table.addCell(add);
                   //  table.addCell("Brand name");
                    table.addCell(v2);
                  //  table.addCell("Manyfacture Name");
                    table.addCell(v3);
                  //   table.addCell("purchase Quantity");
                    table.addCell(v4);
                    table.addCell(v5);
                    table.addCell(v6);
                       
         }
        document.add(table);

         com.itextpdf.text.List list = new com.itextpdf.text.List(true,20);
         list.add("Printed Date:_____________");
         list.add("Signature:_______________");
         document.add(list);
        
         document.add(new Paragraph("--------------------------------------------------------------------------------------"));
         document.add(new Paragraph("\r\r\r Circle",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.add(new Paragraph(" Contact:",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.add(new Paragraph(" Email:",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.close();
        JOptionPane.showMessageDialog(null, "Saved Report");
        }
        catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        
            try{
            String sql = "select sum(PurchaseQuantity), sum(SaleQuantity), sum(TotalQuantity) from '"+jComboBox1.getSelectedItem()+"'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            
            if(rs.next()){
              
                String sum1 = rs.getString("sum(PurchaseQuantity)");
                T_pur.setText(sum1);
               
                String sum2= rs.getString("sum(SaleQuantity)");
                T_sale.setText(sum2);
                
                String sum3 = rs.getString("sum(TotalQuantity)");
                T_Quantity.setText(sum3);
            }
          }
        catch(Exception e){
          JOptionPane.showMessageDialog(null, e);
        }
        Update_table();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void search_tfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_tfKeyReleased
        
             try{
            String sql = "Select * from '"+jComboBox1.getSelectedItem()+"' where ID=?";

            pst = conn.prepareStatement(sql);
            pst.setString(1, search_tf.getText());
            rs= pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("ID");
                id_tf.setText(add1);
                java.util.Date add2 = rs.getDate("Date");
                date_tf.setDate(add2);
                String add3 = rs.getString("BrandName");
                BRname_tf.setText(add3);
                String add4 = rs.getString("ManufactureName");
                MAname_tf.setText(add4);
                String add5 = rs.getString("PurchaseQuantity");
                purchase_tf.setText(add5);
                String add6 = rs.getString("SaleQuantity");
                sale_tf.setText(add6);
                String add7 = rs.getString("TotalQuantity");
                total.setText(add7);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
             
        // For BrandName
        try{

            String sql = "Select * from '"+jComboBox1.getSelectedItem()+"' where BrandName=?";

            pst = conn.prepareStatement(sql);
            pst.setString(1, search_tf.getText().toUpperCase().toLowerCase());
            rs = pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("Id");
                id_tf.setText(add1);
                java.util.Date add2 = rs.getDate("Date");
                date_tf.setDate(add2);
                String add3 = rs.getString("BrandName");
                BRname_tf.setText(add3);
                String add4 = rs.getString("ManufactureName");
                MAname_tf.setText(add4);
                String add5 = rs.getString("PurchaseQuantity");
                purchase_tf.setText(add5);
                String add6 = rs.getString("saleQuantity");
                sale_tf.setText(add6);
                String add7 = rs.getString("TotalQuantity");
                total.setText(add7);

            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
     
        try{

            String sql = "Select * from '"+jComboBox1.getSelectedItem()+"' where ManufactureName=? ";

            pst = conn.prepareStatement(sql);
            pst.setString(1, search_tf.getText().toUpperCase().toLowerCase());
            rs = pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("ID");
                id_tf.setText(add1);
                java.util.Date add2 = rs.getDate("Date");
                date_tf.setDate(add2);
                String add3 = rs.getString("BrandName");
                BRname_tf.setText(add3);
                String add4 = rs.getString("ManufactureName");
                MAname_tf.setText(add4);
                String add5 = rs.getString("PurchaseQuantity");
                purchase_tf.setText(add5);
                String add6 = rs.getString("SaleQuantity");
                sale_tf.setText(add6);
                String add7 = rs.getString("TotalQuantity");
                total.setText(add7);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
         finally{
          try{
           pst.close();
           rs.close();
          }
          catch(Exception e){}
        }
           Update_table();
    }//GEN-LAST:event_search_tfKeyReleased

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        
        dispose();
        SplashScreen ss = new SplashScreen();
        ss.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        close();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        
        id_tf.setText("");
        date_tf.setDate(null);
        BRname_tf.setText("");
        MAname_tf.setText("");
        purchase_tf.setText("");
        Add_Sub.setText("");
        sale_tf.setText("");
        Sale_Add_Sub.setText("");
        total.setText("");
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
        
       MAname_tf.setText(jComboBox1.getSelectedItem().toString());
        
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed

        sno.setText("");
        date.setDate(null);
        PurCom.setSelectedItem(null);
        brand.setText("");
        purchase.setText("");
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed

        try{

            String sno1   = sno.getText();
            String date1  = (((JTextField)date.getDateEditor().getUiComponent()).getText());
            String Manu   = PurCom.getSelectedItem().toString();
            String brand1 = brand.getText();
            String PurQ   = purchase.getText();

            String update = "update '"+PurCom.getSelectedItem()+"' set Id='"+sno1+"', Date='"+date1+"', ManufactureName='"+Manu+"', BrandName='"+brand1+"', purchaseQuantity='"+PurQ+"' where id='"+sno1+"'";

            pst = conn.prepareStatement(update);
            pst.execute();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        finally{
        try{
            rs.close();
            pst.close();

        }
        catch(Exception e){}
          }
        Update_table();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        try{
            String sql = "insert into '"+PurCom.getSelectedItem()+"'(Id, date, ManufactureName, BrandName,PurchaseQuantity) values(?,?,?,?,?)";
            pst = conn.prepareStatement(sql);

            pst.setString(1, sno.getText());
            pst.setString(2, ((JTextField) date.getDateEditor().getUiComponent()).getText());
            pst.setString(3, PurCom.getSelectedItem().toString());
            pst.setString(4, brand.getText());
            pst.setString(5, purchase.getText());

            pst.execute();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
        Update_table();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void purchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchaseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purchaseActionPerformed

    private void brandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brandActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_brandActionPerformed

    private void PurComActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PurComActionPerformed

        try{

            String sql =" select * from  '"+PurCom.getSelectedItem()+"' ";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
            jLabel19.setText("the record will save in "+PurCom.getSelectedItem().toString());

        }
        catch(Exception e){

            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){
            }
        }
    }//GEN-LAST:event_PurComActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        try{

            String val1 = id_tf.getText();
            String val2 =(((JTextField)date_tf.getDateEditor().getUiComponent()).getText());
            //    String Val7 = val2.CURRENT_DATE();
            String val3 = BRname_tf.getText();
            String val4 = MAname_tf.getText();
            String val5 = purchase_tf.getText();
            String val6 = sale_tf.getText();

            double sub = Double.parseDouble(purchase_tf.getText());
            double sub2 = Double.parseDouble(sale_tf.getText());
            double v = sub-sub2;
            total.setText(String.valueOf(v));
            String val7= total.getText();

            String sql = "update '"+jComboBox1.getSelectedItem()+"' set ID='"+val1+"' ,Date='"+val2+"', BrandName='"+val3+"' ,MAnufactureNAme='"+val4+"' ,PurchaseQuantity='"+val5+"' ,SaleQuantity='"+val6+"',TotalQuantity='"+val7+"'  where ID='"+val1+"'";

            pst= conn.prepareStatement(sql);
            if(sub >= sub2){
                pst.execute();
                JOptionPane.showMessageDialog(null, "Updated");}
            else{
                JOptionPane.showMessageDialog(null, "Purchase Quantity must be greater than Sale Quantity");
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        try{
            Update_table();
        }
        finally{
            try{
                pst.close();
                rs.close();
            }
            catch(Exception e){}
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed

        id_tf.setText("");
        date_tf.setDate(null);
        BRname_tf.setText("");
        MAname_tf.setText("");
        purchase_tf.setText("");
        Add_Sub.setText("");
        sale_tf.setText("");
        Sale_Add_Sub.setText("");
        total.setText("");
    }//GEN-LAST:event_ClearActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

        int p = JOptionPane.showConfirmDialog(null,"Do you Really want to Delete","Deleted",JOptionPane.YES_NO_OPTION );

        if(p == 0) {
            try{
                String sql="Delete from '"+jComboBox1.getSelectedItem()+"' where ID=?";

                pst= conn.prepareStatement(sql);
                pst.setString(1, id_tf.getText());

                pst.execute();

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
        try {
            Update_table();
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }

    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

        try{

            String sql = "insert into '"+jComboBox1.getSelectedItem()+"'(ID, Date, BrandName, ManufactureName, PurchaseQuantity, SaleQuantity, TotalQuantity ) values(?,?,?,?,?,?,?)";
            pst = conn.prepareStatement(sql);

            pst.setString(1, id_tf.getText());
            pst.setString(2,  ((JTextField)date_tf.getDateEditor().getUiComponent()).getText());
            pst.setString(3, BRname_tf.getText());
            pst.setString(4, MAname_tf.getText());
            pst.setString(5, purchase_tf.getText());
            pst.setString(6, sale_tf.getText());

            double sub = Double.parseDouble(purchase_tf.getText());
            double sub2 = Double.parseDouble(sale_tf.getText());
            double v = sub-sub2;
            total.setText(String.valueOf(v));
            pst.setString(7,total.getText());

            /*    String val  = purchase_tf.getText();
            String val2  = sale_tf.getText();
            String Total = val-val2;  */
            //    pst.setString(7, Total);
            if( sub >= sub2 ){
                JOptionPane.showMessageDialog(null, "saved");
                pst.execute();
            }
            else{
                JOptionPane.showMessageDialog(null, "Purchase Quantity must be greater than Sale Quantity");
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        try{
            Update_table();
        }

        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        Double SubSale  = Double.parseDouble(sale_tf.getText());
        Double SubSale2 = Double.parseDouble(Sale_Add_Sub.getText());

        Double SaleSubOutput = SubSale - SubSale2;

        sale_tf.setText(String.valueOf(SaleSubOutput));
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        Double SubSale  = Double.parseDouble(sale_tf.getText());
        Double SubSale2 = Double.parseDouble(Sale_Add_Sub.getText());

        Double SaleSubOutput = SubSale + SubSale2;

        sale_tf.setText(String.valueOf(SaleSubOutput));
    }//GEN-LAST:event_jButton5ActionPerformed

    private void Sale_Add_SubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Sale_Add_SubActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Sale_Add_SubActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        Double sub1 =  Double.parseDouble(purchase_tf.getText());
        Double sub2 =  Double.parseDouble(Add_Sub.getText());

        Double output= sub1 - sub2;
        purchase_tf.setText(String.valueOf(output));
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        Double sub1 =  Double.parseDouble(purchase_tf.getText());
        Double sub2 =  Double.parseDouble(Add_Sub.getText());

        Double output= sub1 + sub2;
        purchase_tf.setText(String.valueOf(output));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void MAname_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MAname_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MAname_tfActionPerformed

    private void purchase_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchase_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purchase_tfActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed

        int p = JOptionPane.showConfirmDialog(null,"Do you Really want to Delete","Deleted",JOptionPane.YES_NO_OPTION );

        if(p == 0) {
            try{
                String sql="Delete from '"+jComboBox1.getSelectedItem()+"' where ID=?";

                pst= conn.prepareStatement(sql);
                pst.setString(1, id_tf.getText());

                pst.execute();

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
        try {
            Update_table();
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void tableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableKeyReleased

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP){

            try{
                int row = table.getSelectedRow();
                String table_clicked = (table.getModel().getValueAt(row, 0).toString());
                String sql = "select * from '"+jComboBox1.getSelectedItem()+"' where ID= '"+table_clicked+"' ";

                pst = conn.prepareStatement(sql);
                rs=pst.executeQuery();

                if(rs.next()){

                    String add1 =rs.getString("ID");
                    id_tf.setText(add1);
                    java.util.Date add2 = rs.getDate("Date");
                    date_tf.setDate(add2);
                    String add3 =rs.getString("BrandName");
                    BRname_tf.setText(add3);
                    String add4 =rs.getString("ManufactureName");
                    MAname_tf.setText(add4);
                    String add5 =rs.getString("PurchaseQuantity");
                    purchase_tf.setText(add5);
                    String add6 =rs.getString("SaleQuantity");
                    sale_tf.setText(add6);
                    String add7 =rs.getString("TotalQuantity");
                    total.setText(add7);
                }

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);

            }
        }
    }//GEN-LAST:event_tableKeyReleased

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked

        try{
            int row = table.getSelectedRow();
            String table_clicked = (table.getModel().getValueAt(row, 0).toString());
            String sql = "select * from '"+jComboBox1.getSelectedItem()+"' where ID= '"+table_clicked+"' ";

            pst = conn.prepareStatement(sql);
            rs=pst.executeQuery();

            if(rs.next()){

                String add1 =rs.getString("ID");
                id_tf.setText(add1);
                sno.setText(add1);
                /*  String add2 = rs.getDate("Date").toString();
                date_tf.setDateFormatString(add2);
                //  date_tf.setToolTipText(add2);     */
                /*   String add2 = rs.getString("Date");
                //    date_tf.setDateFormatString(add2);  */
                java.util.Date add2 = rs.getDate("Date");
                date_tf.setDate(add2);
                date.setDate(add2);
                String add3 =rs.getString("BrandName");
                BRname_tf.setText(add3);
                brand.setText(add3);
                String add4 =rs.getString("ManufactureName");
                MAname_tf.setText(add4);
                String add5 =rs.getString("PurchaseQuantity");
                purchase_tf.setText(add5);
                purchase.setText(add5);
                String add6 =rs.getString("SaleQuantity");
                sale_tf.setText(add6);
                String add7 =rs.getString("TotalQuantity");
                total.setText(add7);

                //

                String pur2 = rs.getString("ManufactureName");
                // PurCom.setText(pur2);
                PurCom.setSelectedItem(pur2);
            }

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            //  Update_table();
        }
    }//GEN-LAST:event_tableMouseClicked

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        
        snoS.setText("");
        dateS.setDate(null);
        SalCom.setSelectedItem(null);
        brandS.setText("");
        SalQ.setText("");
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
       
        try{
          String sal = "insert into '"+SalCom.getSelectedItem()+"'(ID, Date, ManufactureName, BrandName, SaleQuantity ) values(?,?,?,?,?)";
          pst= conn.prepareStatement(sal);
          
          pst.setString(1,snoS.getText());
          pst.setString(2,((JTextField)dateS.getDateEditor().getUiComponent()).getText());
          pst.setString(3, SalCom.getSelectedItem().toString());
          pst.setString(4, brandS.getText());
          pst.setString(5, SalQ.getText());
          
          pst.execute();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
           try{
             rs.close();
             pst.close();
           }
           catch(Exception e){}
        }
        Update_table();
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        
        try{
        
            String sns  = snoS.getText();
            String dd   =(((JTextField)dateS.getDateEditor().getUiComponent()).getText());
            String scom = SalCom.getSelectedObjects().toString();
            String bran = brandS.getText();
            String SaQ  = SalQ.getText();
            
            String up = "update '"+SalCom.getSelectedItem()+"' set ID='"+sns+"', Date='"+dd+"', ManufactueName='"+scom+"', BrandName='"+bran+"', SaleQuantity='"+SaQ+"'";
            pst = conn.prepareStatement(up);
            pst.execute();
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(null, e);
        }
        finally{
          try{
            rs.close();
            pst.close();
          }
          catch(Exception e){}
        }
        Update_table();
    }//GEN-LAST:event_jButton18ActionPerformed

    private void SalComActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalComActionPerformed
        
         try{

            String sql =" select * from  '"+SalCom.getSelectedItem()+"' ";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
            jLabel25.setText("the record will save in "+SalCom.getSelectedItem().toString());

        }
        catch(Exception e){

            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){
            }
        }
    }//GEN-LAST:event_SalComActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        
        try{
            String sql5 ="SELECT name FROM sqlite_master WHERE type='table'";
            pst = conn.prepareStatement(sql5);
            rs = pst.executeQuery();
            recordT.setModel(DbUtils.resultSetToTableModel(rs));
            
             String sql6 ="SELECT sum(PurchaseQuantity) FROM sqlite_master WHERE type='table'";
            pst = conn.prepareStatement(sql6);
            rs = pst.executeQuery();
            recordT.setModel(DbUtils.resultSetToTableModel(rs));
            
            for(int a=1; a <= sql5.length(); a++ ){
            String sql = "select sum(PurchaseQuantity), sum(SaleQuantity), sum(TotalQuantity) from '"+a+"'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
           recordT.setModel(DbUtils.resultSetToTableModel(rs));
            
                 if(rs.next()){
                     //     for(int a =1; a<=sql.length(); a++){

                String sum1 = rs.getString("sum(PurchaseQuantity)");
             //    recordT.addItem(sum1);
               
                String sum2= rs.getString("sum(SaleQuantity)");
            //    T_sale.setText(sum2);
                
                String sum3 = rs.getString("sum(TotalQuantity)");
            //    T_Quantity.setText(sum3);
            }
            }   
//            String sql5 ="SELECT name FROM sqlite_master WHERE type='table'";
//            pst = conn.prepareStatement(sql5);
//            rs = pst.executeQuery();
//            recordT.setModel(DbUtils.resultSetToTableModel(rs));
//            for(int a =0; a<=sql5.length(); a++){
//            String sql = "select sum(PurchaseQuantity), sum(SaleQuantity), sum(TotalQuantity) from '"+sql5+"'";
//            pst = conn.prepareStatement(sql);
//            rs = pst.executeQuery();
//            recordT.setModel(DbUtils.resultSetToTableModel(rs));
//            }
//                 if(rs.next()){
//              
//                String sum1 = rs.getString("sum(PurchaseQuantity)");
//             //    recordT.addItem(sum1);
//               
//                String sum2= rs.getString("sum(SaleQuantity)");
//                T_sale.setText(sum2);
//                
//                String sum3 = rs.getString("sum(TotalQuantity)");
//                T_Quantity.setText(sum3);
//            }
        }
        catch(Exception e){}
    }//GEN-LAST:event_jButton19ActionPerformed

    private void recordTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recordTMouseClicked
        
        try{
             String sql5 ="SELECT name FROM sqlite_master WHERE type='table'";
            pst = conn.prepareStatement(sql5);
            rs = pst.executeQuery();
         //   recordT.setModel(DbUtils.resultSetToTableModel(rs));
            
          String sql = "select sum(PurchaseQuantity), sum(SaleQuantity), sum(TotalQuantity) from '"+jComboBox1.getSelectedItem()+"'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
          //  recordT.setModel(DbUtils.resultSetToTableModel(rs));
            
                 if(rs.next()){
                     //     for(int a =1; a<=sql.length(); a++){

                String sum1 = rs.getString("sum(PurchaseQuantity)");
             //    recordT.addItem(sum1);
               
                String sum2= rs.getString("sum(SaleQuantity)");
            //    T_sale.setText(sum2);
                
                String sum3 = rs.getString("sum(TotalQuantity)");
            //    T_Quantity.setText(sum3);
            }
          //  }
        }
        catch(Exception e){}
    }//GEN-LAST:event_recordTMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewTable().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Add_Sub;
    private javax.swing.JTextField BRname_tf;
    private javax.swing.JButton Clear;
    private javax.swing.JLabel Date;
    private javax.swing.JMenu Date_txt;
    private javax.swing.JTextField MAname_tf;
    private javax.swing.JComboBox PurCom;
    private javax.swing.JComboBox SalCom;
    private javax.swing.JTextField SalQ;
    private javax.swing.JTextField Sale_Add_Sub;
    private javax.swing.JTextField T_Quantity;
    private javax.swing.JTextField T_pur;
    private javax.swing.JTextField T_sale;
    private javax.swing.JTextField brand;
    private javax.swing.JTextField brandS;
    private com.toedter.calendar.JDateChooser date;
    private com.toedter.calendar.JDateChooser dateS;
    private com.toedter.calendar.JDateChooser date_tf;
    private javax.swing.JTextField id_tf;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    public javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JTextField purchase;
    private javax.swing.JTextField purchase_tf;
    private javax.swing.JTable recordT;
    private javax.swing.JTextField sale_tf;
    private javax.swing.JTextField search_tf;
    private javax.swing.JTextField sno;
    private javax.swing.JTextField snoS;
    public javax.swing.JTable table;
    private javax.swing.JLabel time_txt;
    private javax.swing.JTextField total;
    // End of variables declaration//GEN-END:variables
//String tname = null;
  //  http://9gag.com/gag/a1Xm7nD?ref=fbp
}
