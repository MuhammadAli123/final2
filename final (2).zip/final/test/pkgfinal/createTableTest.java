/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ali
 */
public class createTableTest {
    
    public createTableTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of icon method, of class createTable.
     */
    @Test
    public void testIcon() {
        System.out.println("icon");
        createTable instance = new createTable();
        instance.icon();
     
    }

    /**
     * Test of joo method, of class createTable.
     */
    @Test
    public void testJoo() {
        System.out.println("joo");
        createTable instance = new createTable();
        instance.joo();
     
    }

    /**
     * Test of main method, of class createTable.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        createTable.main(args);
       
    }
    
}
