/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ali
 */
public class viewTableTest {
    
    public viewTableTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of Update_table method, of class viewTable.
     */
    @Test
    public void testUpdate_table() {
        System.out.println("Update_table");
        viewTable instance = new viewTable();
        instance.Update_table();
       
    }

    /**
     * Test of close method, of class viewTable.
     */
    @Test
    public void testClose() {
        System.out.println("close");
        viewTable instance = new viewTable();
        instance.close();
        
    }

    /**
     * Test of icon method, of class viewTable.
     */
    @Test
    public void testIcon() {
        System.out.println("icon");
        viewTable instance = new viewTable();
        instance.icon();
        
    }

    /**
     * Test of currentDate method, of class viewTable.
     */
    @Test
    public void testCurrentDate() {
        System.out.println("currentDate");
        viewTable instance = new viewTable();
        instance.currentDate();
        
    }

    /**
     * Test of main method, of class viewTable.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        viewTable.main(args);
       
    }
    
}
