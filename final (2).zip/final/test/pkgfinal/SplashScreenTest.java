/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ali
 */
public class SplashScreenTest {
    
    public SplashScreenTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of icon method, of class SplashScreen.
     */
    @Test
    public void testIcon() {
        System.out.println("icon");
        SplashScreen instance = new SplashScreen();
        instance.icon();
      
    }

    /**
     * Test of main method, of class SplashScreen.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        SplashScreen.main(args);
      
    }
    
}
